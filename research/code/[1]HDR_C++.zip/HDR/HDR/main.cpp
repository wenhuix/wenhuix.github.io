#include "HDR.h"
#include "tonemap.h"
#include "cvImage.h"

#include <iostream>
#include <fstream>

#include "hdrIO.h"
//#define SHAKE
//#define ALIGNMENT


//translate color image
void tRgbImage(IplImage *src, IplImage *dst, int x, int y)
{
	IplImage* img = cvCreateImage( cvSize(src->width, src->height), 8, 3 );
	cvCopyImage( src, img );
	RgbImage Img( img ), Dst(dst);
	cvZero( dst );
	int height = dst->height, width = dst->width;
	for(int i=0;i<height;++i)
		for(int j=0;j<width;++j)
		{
			Dst[i][j].r = Img[min(max(0,i-y),height-1)][min(max(0,j-x),width-1)].r;
			Dst[i][j].g = Img[min(max(0,i-y),height-1)][min(max(0,j-x),width-1)].g;
			Dst[i][j].b = Img[min(max(0,i-y),height-1)][min(max(0,j-x),width-1)].b;
		}
	cvReleaseImage( &img );
}

int main(int argc, char** argv)
{
	int P;
	IplImage** imgs;
	float rRC[256], gRC[256], bRC[256];
	float* shutter_speed;

	char filename[128], path[256] = {};
	if(argc==3)
	{
		sprintf( path, "%s", argv[2] );
		sprintf( filename, "%s\\%s", path, argv[1]);
	}
	else
		sprintf( filename, "%s", argv[1]);

	std::ifstream is( filename );
	if(is.fail())
	{
		printf("cannot read the description file\n");
		system("pause");
		exit(1);
	}
	///////////////////////////////////////////////
	//read images and translate the position if needed
	is>>P;	
	imgs = new IplImage*[P];
	shutter_speed = new float[P];
	for(int i=0;i<P;++i)
	{
		char bmp[128];

		is>>bmp;
		is>>shutter_speed[i];

		sprintf(filename, "%s\\%s", path, bmp);
		imgs[i] = cvLoadImage(filename);
		if(imgs[i]==NULL)
		{
			printf("cannot read the image files\n");
			system("pause");
			exit(1);
		}

#define MAX_SIZE 800
		if(imgs[i]->height>MAX_SIZE || imgs[i]->width>MAX_SIZE)
		{
			int width = imgs[i]->width, height = imgs[i]->height;
			int larger = max(height, width);
			float ratio = (float)MAX_SIZE / larger;
			IplImage* tmp = cvCreateImage(cvSize((int)(ratio*width), (int)(ratio*height)), 8, 3);
			cvResize( imgs[i], tmp );
			cvReleaseImage( &(imgs[i]) );
			imgs[i] = tmp;

		}
#ifdef SHAKE
		//simulate shaking
		tRgbImage(imgs[i], imgs[i], rand()%20, rand()%20);
		cvNamedWindow( "img" );
		cvShowImage("img",imgs[i]);
		printf("%d\n",i);
		cvWaitKey(0);
#endif
	}
	is.close();




	////////////////////////////////////////////////
	
#ifdef ALIGNMENT
	//do alignment
	printf("==============================================================\n");
	printf("                          Do Alignment\n");
	alignment( imgs[P/2], imgs, P );
	printf("                           Finished!\n");
//#ifdef SHAKE
	for(int i=0;i<P;++i)
	{
		cvNamedWindow( "img" );
		cvShowImage("img",imgs[i]);
		printf("%d\n",i);
		cvWaitKey(0);
	}
//#endif
#endif

	//////////////////////////////////////////////////////
	//recover response curve
	printf("==============================================================\n");
	printf("                     Recover Response Curve\n");
	printf("solving SVD for R channel...\n");
	responseCurve(bRC, shutter_speed, imgs, P, 0 );
	printf("solving SVD for G channel...\n");
	responseCurve(gRC, shutter_speed, imgs, P, 1 );
	printf("solving SVD for B channel...\n");
	responseCurve(rRC, shutter_speed, imgs, P, 2 );
	printf("                           Finished!\n");

	//write response curve to file
	std::ofstream gout;
	gout.open( "g.txt" );
	for(int i=0;i<256;++i)
		gout<<rRC[i]<<" "<<gRC[i]<<" "<<bRC[i]<<"\n";
	gout.close();

	//////////////////////////////////////////////////////
	//reconstruct radiance map

	printf("==============================================================\n");
	printf("                    Reconstruct Radience Map\n");
	IplImage* radMap = cvCreateImage( cvSize( imgs[0]->width, imgs[0]->height ), 32, 3 );
	reconstructRadianceMap( radMap, imgs, shutter_speed, P, rRC, gRC, bRC );
	printf("                           Finished!\n");

	//write to .hdr
	floatImageToHdr( radMap, "HDR.hdr" );
	//floatImageToRaw( radMap, "test.raw" );

	//for gradient tonemapping, but not used now
	//IplImage* radMap;
	//hdrToFloatImage(radMap, "test.hdr" );

	//release resource
	for(int i=0;i<P;++i)	
		cvReleaseImage( &(imgs[i]) );
	

	//////////////////////////////////////////////////////
	// tonemapping	

	printf("==============================================================\n");
	printf("                         Tone Mapping\n\n");
	IplImage* toneMap = cvCreateImage( cvSize(radMap->width, radMap->height), 8, 3 );

	printf("                     Direct Scaling Method\n");
	noToneMapping( radMap, toneMap );
	printf("                           Finished!\n\n");
	cvSaveImage( "noToneMapping.bmp", toneMap );
	cvNamedWindow( "without tone mapping" );
	cvShowImage( "without tone mapping", toneMap );
	cvWaitKey(5);

	printf("                   Dodging and Burning Method\n");
	tonemapping( radMap, toneMap);
	printf("                           Finished!\n\n");
	cvSaveImage( "dodging.bmp", toneMap );

	cvNamedWindow( "dodging and burning" );
	cvShowImage( "dodging and burning", toneMap );
	cvWaitKey(5);

	printf("                        Bilateral Method\n");
	bilateralToneMapping(radMap, toneMap);
	printf("                          All Finished!\n");
	printf("==============================================================");

	cvSaveImage( "bilateral.bmp", toneMap );	
	cvNamedWindow( "bilateral" );
	cvShowImage( "bilateral", toneMap );
	cvWaitKey( 0 );

	cvReleaseImage( &radMap );
	cvReleaseImage( &toneMap );
}

