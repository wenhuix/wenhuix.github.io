#pragma once

#include <cxcore.h>

template<class T> class cvImage
{
public:
	IplImage* imgp;
public:  
	cvImage(IplImage* img=0) {imgp=img;}
	~cvImage(){imgp=0;}
	void operator=(IplImage* img) {imgp=img;}
	inline T* operator[](const int rowIndx) {
		return ((T *)(imgp->imageData + rowIndx*imgp->widthStep));}
};
typedef struct{
	unsigned char b,g,r;
} RgbPixel;
typedef struct{
	float b,g,r;
} RgbPixelFloat;
typedef cvImage<RgbPixel>       RgbImage;
typedef cvImage<RgbPixelFloat>  RgbImageFloat;
typedef cvImage<unsigned char>  BwImage;
typedef cvImage<float>          BwImageFloat;
typedef cvImage<double>     	BwImageDouble;
