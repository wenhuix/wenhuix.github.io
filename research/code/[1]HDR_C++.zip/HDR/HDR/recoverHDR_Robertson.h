#include <cstdio>

#include "cv.h"
#include "cxcore.h"
#include "highgui.h"
