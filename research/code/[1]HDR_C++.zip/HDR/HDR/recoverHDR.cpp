#include "cvImage.h"
#include "HDR.h"

#include <iostream>	//this is needed, or there would be error when including taucs. I don't know why...

/*
#include "../../taucs/taucsaddon.h"

//only format CvMat CV_32FC1 is supported

void cvMatToCCS(CvMat* mat, taucs_ccs_matrix **pAt)
{
	int nonzero = cvCountNonZero( mat );
	*pAt = taucs_ccs_create(mat->rows,mat->cols,nonzero,TAUCS_DOUBLE);
	double* vals = (*pAt)->taucs_values;
	int* colptr = (*pAt)->colptr;
	int* rowind = (*pAt)->rowind;

	int k = 0;
	for(int c=0;c<mat->cols;++c)
	{
		colptr[c] = k;
		for(int r=0;r<mat->rows;++r)
		{
			if( cvmGet(mat, r, c) )
			{
				rowind[k] = r;
				vals[k] = cvmGet(mat, r, c);				
				++k;
			}
		}
	}
	colptr[mat->cols] = k;
}
*/

#define Z_MID 127.5f
inline float weight(int z){return Z_MID + 0.1 - abs((float)z-Z_MID);};

void responseCurve(float rc[256],
				    float* shutter_speed,
					IplImage** imgs,
					int P,
					int channel)
{
#define N 128
	//sample points
	int *x_pos, *y_pos;
	int width = imgs[0]->width, height = imgs[0]->height;
	x_pos = new int[N];
	y_pos = new int[N];
	for(int i=0;i<N;++i)
	{
		x_pos[i] = rand()%width;
		y_pos[i] = rand()%height;
	}

	IplImage** colorChannels;
	colorChannels = new IplImage*[P];
	for(int i=0;i<P;++i)
	{
		colorChannels[i] = cvCreateImage( cvSize( width, height ), 8, 1 );
		
		if(channel==0)
			cvSplit( imgs[i], colorChannels[i], NULL, NULL, NULL );
		else if(channel==1)
			cvSplit( imgs[i], NULL, colorChannels[i], NULL, NULL );
		else
			cvSplit( imgs[i], NULL, NULL, colorChannels[i], NULL );
	}

	//setting matrix
	int R = N * P + 1 + 254;
	int C = 256 + N;
	int A_nonzero = 2 * N * P + 1 + 3 * 254;

	float* b = new float[R];
	float* x = new float[C];
	CvMat* tmpMat = cvCreateMat( R, C, CV_32FC1 );

	cvZero( tmpMat );
	for(int r=0;r<R;++r)
		b[r] = 0;

	int k = 0;
	for(int n=0;n<N;++n)
		for(int p=0;p<P;++p)
		{
			BwImage Img( colorChannels[p] );
			int g = Img[y_pos[n]][x_pos[n]];
			float w = weight( g );
			cvmSet( tmpMat, k, g, w);
			cvmSet( tmpMat, k, 256+n, -w);
			b[k] = w*log(shutter_speed[p]);
			++k;
		}
	
	cvmSet( tmpMat, k, 128, 1 );
	++k;

#define Lambda 30.f
	for(int i=0;i<256-2;++i)
	{
		cvmSet( tmpMat, k, i, Lambda * weight(i) );
		cvmSet( tmpMat, k, i+1, -2 * Lambda * weight(i) );
		cvmSet( tmpMat, k, i+2, Lambda * weight(i) );
		++k;
	}

	for(int i=0;i<P;++i)
	{
		cvReleaseImage( &(colorChannels[i]) );
	}

	//Sparse Linear System
	//build sparse matrix
	//cannot work so far... QQ
	/*
	taucs_ccs_matrix* A;
	cvMatToCCS(tmpMat, &A);
	char* options[] = { "taucs.factor.LU=true", NULL }; 
	if (taucs_linsolve(A, NULL, 1, x, b, options, NULL ) != TAUCS_SUCCESS) {
		std::cout << "Solving failed\n";
	}
	*/
	
	
	CvMat* U = cvCreateMat( R, R, CV_32FC1 );
	CvMat* W = cvCreateMat( R, C, CV_32FC1 );
	CvMat* V = cvCreateMat( C, C, CV_32FC1 );
	CvMat* B = cvCreateMat( R, 1, CV_32FC1 );
	CvMat* X = cvCreateMat( C, 1, CV_32FC1 );

	cvSVD( tmpMat, W, U, V, CV_SVD_MODIFY_A );
	for(int i=0;i<R;++i)
	{
		cvmSet( B, i, 0, b[i] );
	}
	cvSVBkSb( W, U, V, B, X, CV_SVD_MODIFY_A );
	
	for(int i=0;i<256;++i)
		rc[i] = (float)cvmGet(X,i,0);
	

	cvReleaseMat( &U );
	cvReleaseMat( &W );
	cvReleaseMat( &V );
	cvReleaseMat( &B );
	cvReleaseMat( &X );	
	
	cvReleaseMat( &tmpMat );

	delete [] b;
	delete [] x;
	delete [] x_pos;
	delete [] y_pos;
}

void reconstructRadianceMap(IplImage* radMap, 
								IplImage** imgs, 
								float* shutter_speed,
								int P,
								float rRC[256], 
								float gRC[256], 
								float bRC[256] )
{
	int rZ, gZ, bZ;
	float rW, gW, bW;
	float rSum, rWeightSum;
	float gSum, gWeightSum;
	float bSum, bWeightSum;

	RgbImageFloat RadMap( radMap );
	for(int r=0;r<radMap->height;++r)
		for(int c=0;c<radMap->width;++c)
		{
			rSum = gSum = bSum = 0;
			rWeightSum = gWeightSum = bWeightSum = 0;
			for(int p=0;p<P;++p)
			{				
				RgbImage Img(imgs[p]);

				rZ = Img[r][c].r;
				gZ = Img[r][c].g;
				bZ = Img[r][c].b;
				rW = weight( rZ );
				gW = weight( gZ );
				bW = weight( bZ );

				rSum += (rW*(rRC[rZ]-log(shutter_speed[p])));
				gSum += (gW*(gRC[gZ]-log(shutter_speed[p])));
				bSum += (bW*(bRC[bZ]-log(shutter_speed[p])));
				rWeightSum += rW;
				gWeightSum += gW;
				bWeightSum += bW;
			}

			RadMap[r][c].r = exp( rSum / rWeightSum );
			RadMap[r][c].g = exp( gSum / gWeightSum );
			RadMap[r][c].b = exp( bSum / bWeightSum );
		}
}	