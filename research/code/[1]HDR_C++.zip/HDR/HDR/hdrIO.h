//#include "cxcore.h"
#include "cv.h"

void floatImageToRaw(IplImage* img, const char* filename);
void floatImageToHdr(IplImage* img, const char* filename);
void hdrToFloatImage(IplImage* img, const char* filename);