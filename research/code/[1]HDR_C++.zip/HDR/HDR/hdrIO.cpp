
#include <gil/gil.h>
using namespace gil;
#include "cvImage.h"

#include "cv.h"
#include "cxcore.h"
#include "highgui.h"

#include "hdrIO.h"

#ifdef min
#undef min
#endif
#ifdef max
#undef max
#endif

void floatImageToRaw(IplImage* img, const char* filename)
{
	if(img->depth!=32)
		fprintf(stderr,"wrong input for float To Hdr, the pixel type must be float");

	FloatImage3 fi(img->width,img->height); 
	FILE* fid = fopen(filename,"wb");
	int width = img->width, height = img->height;
	fwrite( &width, sizeof(int), 1, fid );
	fwrite( &height, sizeof(int), 1, fid );
	fwrite( img->imageData, 1, (img->widthStep)*(img->height), fid );
	fclose(fid);
}

void floatImageToHdr(IplImage* img, const char* filename)
{
	if(img->depth!=32)
		fprintf(stderr,"wrong input for float To Hdr, the pixel type must be float");
	RgbImageFloat Img(img);

	FloatImage3 fi(img->width,img->height); 
	for (size_t y = 0; y < fi.height(); ++y)
		for (size_t x = 0; x < fi.width(); ++x)
		{
			fi(x,y)[0] = Img[y][x].r;
			fi(x,y)[1] = Img[y][x].g;
			fi(x,y)[2] = Img[y][x].b;
		}
	write( fi, filename );
}


void hdrToFloatImage(IplImage* img, const char* filename)
{
	FloatImage3 fi;
	read( fi, filename );

	img = cvCreateImage( cvSize( fi.width() , fi.height() ), 32, 3 );
	RgbImageFloat Img( img );
	for (size_t y = 0; y < fi.height(); ++y)
		for (size_t x = 0; x < fi.width(); ++x)
		{
			Img[y][x].r = fi(x,y)[0];
			Img[y][x].g = fi(x,y)[1];
			Img[y][x].b = fi(x,y)[2];
		}
}

