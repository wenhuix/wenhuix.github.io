#include <cstdio>

#include "cv.h"
#include "cxcore.h"
#include "highgui.h"

void getLuminance(IplImage* radMap, IplImage* lum);

//normalize to 0~255 directly
void noToneMapping(IplImage* radMap, IplImage* toneMap);

//dodging and burning
void tonemapping(IplImage* radMap, IplImage* toneMap);
void guassianFilter(IplImage* src, IplImage* dst, int s);

//bilateral
void bilateralToneMapping(IplImage* radMap, IplImage* toneMap, float contrast = 3 );