// for documentary, see "Estimation-theoretic approach to dynamic range. enhancement using multiple exposures.pdf"

#include "cvImage.h"
#include "recoverHDR_Robertson.h"

#define Z_MID 127.5f
inline float weight(int z){return Z_MID + 0.1 - abs((float)z-Z_MID);};

void responseCurve2(float rc[256],
				    float* shutter_speed,
					IplImage** imgs,
					int P,
					int channel)
{
#define N 128
	//sample points
	int *x_pos, *y_pos;
	int width = imgs[0]->width, height = imgs[0]->height;
	x_pos = new int[N];
	y_pos = new int[N];
	for(int i=0;i<N;++i)
	{
		x_pos[i] = rand()%width;
		y_pos[i] = rand()%height;
	}

	IplImage** colorChannels;
	colorChannels = new IplImage*[P];
	for(int i=0;i<P;++i)
	{
		colorChannels[i] = cvCreateImage( cvSize( width, height ), 8, 1 );
		
		if(channel==0)
			cvSplit( imgs[i], colorChannels[i], NULL, NULL, NULL );
		else if(channel==1)
			cvSplit( imgs[i], NULL, colorChannels[i], NULL, NULL );
		else
			cvSplit( imgs[i], NULL, NULL, colorChannels[i], NULL );
	}

	// get all points intensity
	int* Z[N];
	for(int n=0;n<N;n++)
		Z[n] = new int[P];

	for(int p=0;p<P;p++)
		for(int n=0;n<N;n++)
		{
			BwImage Img( colorChannels[p] );
			Z[n][p] = Img[x_pos[n]][y_pos[n]];
		}

	// initialization
	int g[256];
	int b = 0.0001;
	int m = (1-b)/127;
	for(int i=0;i<256;i++)
	{
		g[i] = m*i+b;
	}

	// estimation
	int E[N];
	for(int n=0;n<N;n++)
		E[n] = 0;

	while(1)
	{
		// E step
		int divide_scale = 0;
		for(int n=0;n<N;n++)
		{
			for(int p=0;p<P;p++)
			{
				E[n] += weight(Z[n][p])*g[Z[n][p]]*shutter_speed[p];
				divide_scale += weight(Z[n][p])*pow(shutter_speed[p],2);
			}
			E[n] /= divide_scale;
		}

		// M step
		int g_new[256];
		int count[256];
		for(int i=0;i<256;i++)
		{
			g_new[i] = 0;
			count[i] = 0;
		}

		for(int n=0;n<N;n++)
			for(int p=0;p<P;p++)
			{
				g_new[Z[n][p]] += E[n]*shutter_speed[p];
				count[Z[n][p]] += 1;
			}
		
		for(int i=0;i<256;i++)
			if(count[i]!=0)
			{
				g_new[i] /= count[i];
			}

		// normalize g_new so that g[128]=1
		for(int i=0;i<256;i++)
			g_new[i] = g_new[i]-g_new[128]+1;

		// end
		for(int i=0;i<256;i++)
			g[i] = g_new[i];
	}
}