#include "tonemap.h"
#include "cvImage.h"
#include <cstdio>
#include "math.h"

#include <vector>
using std::vector;

#define GLOBAL
//#define LOCAL

void getLuminance(IplImage* radMap, IplImage* lum)
{
	BwImageFloat Lum(lum);
	RgbImageFloat RadMap( radMap );

	for(int r=0;r<radMap->height;r++)
		for(int c=0;c<radMap->width;c++)
		{
			// suggestted by "Tone Reproduction: A Perspective from Luminance-Driven Perceptual Grouping"
			Lum[r][c] = 0.2126f*RadMap[r][c].r+0.7152f*RadMap[r][c].g+0.0722f*RadMap[r][c].b;
		}
}

void noToneMapping(IplImage* radMap, IplImage* toneMap)
{
	IplImage* lum = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
	IplImage* newLum = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
	
	RgbImageFloat RadMap( radMap );
	BwImageFloat Lum(lum);	
	BwImageFloat NewLum(newLum);	
	RgbImage ToneMap( toneMap );


	getLuminance( radMap, lum );
	cvNormalize( lum, newLum, 255, 0, CV_MINMAX );

	for(int r=0;r<radMap->height;r++)
		for(int c=0;c<radMap->width;c++)
		{
			float ratio = NewLum[r][c] / Lum[r][c];
			ToneMap[r][c].r = min( 255, RadMap[r][c].r * ratio );
			ToneMap[r][c].g = min( 255, RadMap[r][c].g * ratio );
			ToneMap[r][c].b = min( 255, RadMap[r][c].b * ratio );
		}

	cvReleaseImage( &lum );
	cvReleaseImage( &newLum );
}

void guassianFilter(IplImage* src, IplImage* dst, int s)
{
	int kernal_size = 51;
	double alpha = 1.6;
	
	double weight[51][51];
	CvPoint center = cvPoint(kernal_size/2, kernal_size/2);
	
	double sum = 0;
	for(int r=0;r<kernal_size;r++)
	{
		double dx = (double)(r-center.x);
		for(int c=0;c<kernal_size;c++)
		{
			double dy = (double)(c-center.y);
			weight[r][c]=exp(-1*(dx*dx+dy*dy)/pow(alpha*s,2)) / (3.1415*pow(alpha*s,2));
			sum = sum + weight[r][c];
		}
	}
	
	
	for(int r=0;r<kernal_size;r++)
		for(int c=0;c<kernal_size;c++)
		{
			weight[r][c] /= sum; 
		}
	

	CvMat* kernal = cvCreateMat( kernal_size, kernal_size, CV_32FC1);
	for(int r=0;r<kernal_size;r++)
		for(int c=0;c<kernal_size;c++)
			cvmSet( kernal, r, c, weight[r][c]);

	int length = (kernal_size-1)/2;
	cvFilter2D( src, dst, kernal, cvPoint(length, length));

	cvReleaseMat( &kernal );


}

void tonemapping(IplImage* radMap, IplImage* toneMap)
{
	IplImage* lum = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
	getLuminance(radMap, lum);

	float delta = 1;
	float a = 0.36f;
	float Lw=0.0;
	float Lwrite = 700;

	BwImageFloat Lum(lum);
	for(int r=0;r<radMap->height;r++)
		for(int c=0;c<radMap->width;c++)
		{
			Lw += log(delta+Lum[r][c]);
		}
	Lw = exp(Lw/(radMap->height*radMap->width)); // 11.476
	//printf("Lw: %f\n",Lw);

	IplImage* l = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
	BwImageFloat L( l );
	float max = 0;
	float min = 10000000;
	for(int r=0;r<radMap->height;r++)
		for(int c=0;c<radMap->width;c++)
		{
			L[r][c] = a*Lum[r][c]/Lw;
			if(max<L[r][c])
				max = L[r][c];
			if(min>L[r][c])
				min = L[r][c];
		}
	//printf("Lum_after: %f %f\n", min,max); 

	////////////////////////////
	// global

#ifdef GLOBAL

	IplImage* ld = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
	BwImageFloat Ld( ld );

	max = 0;
	min = 100000;
	for(int r=0;r<radMap->height;r++)
		for(int c=0;c<radMap->width;c++)
		{
			//Ld[r][c] = L[r][c] / (1+L[r][c]);
			Ld[r][c] = L[r][c]*(1+L[r][c]/pow(Lwrite,2)) / (1+L[r][c]);
			if(max<Ld[r][c])
				max = Ld[r][c];
			if(min>Ld[r][c])
				min = Ld[r][c];
		}
	printf("Ld: %f %f\n",min,max);

	RgbImage ToneMap( toneMap );
	RgbImageFloat RadMap( radMap );
	for(int r=0;r<radMap->height;r++)
		for(int c=0;c<radMap->width;c++)
		{
			ToneMap[r][c].r = min( 255, 255*RadMap[r][c].r/Lum[r][c]*Ld[r][c]);
			ToneMap[r][c].g = min( 255, 255*RadMap[r][c].g/Lum[r][c]*Ld[r][c]);
			ToneMap[r][c].b = min( 255, 255*RadMap[r][c].b/Lum[r][c]*Ld[r][c]);
		}

	cvReleaseImage( &lum );
	cvReleaseImage( &ld );
	cvReleaseImage( &l );
#endif

	////////////////////////////////
	// local

#ifdef LOCAL

	
	double alpha = 1.6;
	int phi = 10;
	

	/*

	float epi = 0.001;
	int kernal_size = 51;

	IplImage* ld = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
	BwImageFloat Ld( ld );
	for(int r=0;r<radMap->height;r++)
	{
		for(int c=0;c<radMap->width;c++)
		{
			int temp_s = 1;
			float v1, v2, weight, v;
			while(1)
			{
				int length = (kernal_size-1)/2;
				v1 = 0;
				v2 = 0;
				for(int i=-length;i<=length;i++)
					for(int j=-length;j<=length;j++)
					{
						
						if(r+i>0 && r+i<radMap->height && c+j>0 && c+j<radMap->width)
						{
							weight = exp(-1*(i*i+j*j)/pow(alpha*temp_s,2.0)) / (3.1415*pow(alpha*temp_s,2.0));
							v1 += weight*L[r+i][c+j];
							weight = exp(-1*(i*i+j*j)/pow(alpha*(temp_s+1),2.0)) / (3.1415*pow(alpha*(temp_s+1),2.0));
							v2 += weight*L[r+i][c+j];
						}
					}
				v = (v1-v2) / ( pow(2.0,phi)*a/pow(temp_s,2.0)+v1 );
				if(abs(v)>epi || temp_s>length)
				{
					//cvmSet( s, r, c, temp_s);
					//if(L[r][c]>1)
					//	printf("stop!!\n");
					Ld[r][c] = L[r][c]/(1+v1);
					//printf("%d %f %f %f\n",temp_s, v1, L[r][c], Ld[r][c]);
					break;
				}
				else
					temp_s += 1;
			}
		}
		printf("%d ",r);
	}

		
	for(int r=0;r<radMap->height;r++)
	{
		for(int c=0;radMap->width;c++)
		{
			printf("%f ",cvmGet(s,r,c));
		}
		printf("\n");
	}
	

	*/
	
	float epi = 0.001;
	int N_level = 20;
	IplImage** vs;
	BwImageFloat* Vs = new BwImageFloat[N_level];
	vs = new IplImage*[N_level];
	for(int s=0;s<N_level;s++)
	{
		vs[s] = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
		guassianFilter(l, vs[s], s+1);
		Vs[s] = BwImageFloat( vs[s] );
	}


	IplImage* ld = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
	BwImageFloat Ld( ld );
	double v;
	for(int r=0;r<radMap->height;r++)
	{
		for(int c=0;c<radMap->width;c++)
		{
			for(int s=1;s<N_level;s++)
			{
				v = (Vs[s][r][c]-Vs[s-1][r][c]) / (pow(2.0,phi)*a/pow(s-1,2.0)+Vs[s-1][r][c]);
				//printf("%d %f %f %f\n", s-1, Vs[s-1][r][c], Vs[s][r][c], v);
				if(abs(v)>epi)
				{
					Ld[r][c] = L[r][c]/(1+Vs[s-1][r][c]);
					//printf("%f\n",Ld[r][c]);
					break;
				}
				else if(s==N_level-1)
					Ld[r][c] = L[r][c]/(1+Vs[s][r][c]);

			}
			//printf("\n\n");
		}
	}



	RgbImage ToneMap( toneMap );
	RgbImageFloat RadMap( radMap );
	for(int r=0;r<radMap->height;r++)
		for(int c=0;c<radMap->width;c++)
		{
			ToneMap[r][c].r = min( 255, 255*RadMap[r][c].r/Lum[r][c]*Ld[r][c]);
			ToneMap[r][c].g = min( 255, 255*RadMap[r][c].g/Lum[r][c]*Ld[r][c]);
			ToneMap[r][c].b = min( 255, 255*RadMap[r][c].b/Lum[r][c]*Ld[r][c]);
	}

	for(int i=0;i<N_level;++i)	
		cvReleaseImage( &(vs[i]) );
	cvReleaseImage( &lum );
	cvReleaseImage( &ld );
	cvReleaseImage( &l );

#endif

}

void logImage(IplImage* img, IplImage* logImg)
{
	BwImageFloat Img(img);
	BwImageFloat LogImg(logImg);
	for(int i=0;i<img->height;++i)
		for(int j=0;j<img->width;++j)
		{
			LogImg[i][j] = log10f(max( Img[i][j], 0.0000001f ));			
		}
}

vector<float> generateGaussianFilter(int n, float sigma)
{
	vector<float> gaussian( (2*n+1)*(2*n+1) );

	float invSigmaSquare = 1.f/(sigma*sigma);
	int index;
	float total = 0;
	for(int i=-n;i<=n;++i)
		for(int j=-n;j<=n;++j)
		{
			index = (i+n)*(2*n+1)+(j+n);
			gaussian[index] = exp( -0.5f*(i*i+j*j)*invSigmaSquare );
			total += gaussian[index];
		}

	float inv_total = 1.f/total;
	for(int i=0;i<(2*n+1)*(2*n+1);++i)
		gaussian[i]*=inv_total;

	return gaussian;
};

void bilateralFilter(IplImage* in, IplImage* out)
{
	BwImageFloat In(in);
	BwImageFloat Out(out);

	int height = in->height, width = in->width;
	float sigma_s = 0.02f * (height+width);
	int n = cvRound( 2.6 * sigma_s );
	vector<float> filter = generateGaussianFilter( n , sigma_s );

#define sigma_i 0.4f
	float inv_si = 1.f / (sigma_i*sigma_i);
	int cx, cy;
	for(int y=0;y<height;++y)
		for(int x=0;x<width;++x)
		{
			float i  = 0;
			float ki = 0;
			for(int dy=-n;dy<=n;++dy)
			{
				float i0 = In[y][x];

				cy = y + dy;
				if(cy < 0 || cy >= height)
					continue;
				for(int dx=-n;dx<=n;++dx)
				{
					cx = x + dx;
					if(cx < 0 || cx >= width)
						continue;

					float i1 = In[cy][cx];
					float w = exp(-0.5f*(i1-i0)*(i1-i0)*inv_si);
					int index = (dy+n)*(2*n+1)+dx+n;
					i  += w * filter[index] * i1;
					ki += w * filter[index];
				}
			}
			Out[y][x] = i/ki;
		}
}

void getDetail( IplImage* logLum, IplImage* logBase, IplImage* logDetail )
{
	BwImageFloat LogLum( logLum );
	BwImageFloat LogBase( logBase );
	BwImageFloat LogDetail( logDetail );

	for(int i=0;i<logLum->height;++i)
		for(int j=0;j<logLum->width;++j)
			LogDetail[i][j] = LogLum[i][j] - LogBase[i][j];
}

void getOutputLuminance( IplImage* logBase, IplImage* logDetail, IplImage* outLum, float contrast )
{
	BwImageFloat LogBase(logBase);
	BwImageFloat LogDetail(logDetail);
	BwImageFloat OutLum(outLum);

	
	float maximum = -(INT_MAX), minimum = INT_MAX;
	for(int i=0;i<logBase->height;++i)
		for(int j=0;j<logBase->width;++j)
		{
			maximum = maximum > LogBase[i][j] ? maximum : LogBase[i][j];
			minimum = minimum < LogBase[i][j] ? minimum : LogBase[i][j];
		}
	

	//compression factor : targetContrast/(max(log(base)) - min(log(base)))
	float targetContrast = log10f(contrast);
	float compressionFactor = targetContrast / (maximum - minimum);
	for(int i=0;i<logBase->height;++i)
		for(int j=0;j<logBase->width;++j)
			OutLum[i][j] = pow( 10.f, LogBase[i][j] * compressionFactor + LogDetail[i][j] /*- maximum*/ );

	cvNormalize( outLum, outLum, 1, 0, CV_MINMAX );
}

void backToRGB( IplImage* rad, IplImage* lum, IplImage* newLum, IplImage* rgb )
{
	RgbImageFloat Rad( rad );
	RgbImageFloat Rgb( rgb );
	BwImageFloat Lum( lum );
	BwImageFloat NewLum( newLum );

	for(int i=0;i<rad->height;++i)
		for(int j=0;j<rad->width;++j)
		{
			float ratio = NewLum[i][j] / Lum[i][j];
			Rgb[i][j].r = Rad[i][j].r * ratio;
			Rgb[i][j].g = Rad[i][j].g * ratio;
			Rgb[i][j].b = Rad[i][j].b * ratio;
		}
}

void floatToChar( IplImage* floatImage, IplImage* ucImage )
{
	RgbImageFloat FloatImage( floatImage );
	RgbImage UcImage( ucImage );
	for(int i=0;i<floatImage->height;++i)
		for(int j=0;j<floatImage->width;++j)
		{
			UcImage[i][j].r = min( 255, 255 * FloatImage[i][j].r );
			UcImage[i][j].g = min( 255, 255 * FloatImage[i][j].g );
			UcImage[i][j].b = min( 255, 255 * FloatImage[i][j].b );
		}
}

//reference
//http://people.csail.mit.edu/fredo/PUBLI/Siggraph2002/index.html#hdr
void bilateralToneMapping(IplImage* radMap, IplImage* toneMap, float contrast )
{
	IplImage* lum = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
	IplImage* logLum = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
	IplImage* logBase = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
	IplImage* logDetail = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
	IplImage* outLum = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 1 );
	IplImage* floatTone = cvCreateImage( cvSize( radMap->width, radMap->height ), 32, 3 );

	//Pseudo Code : input intensity= 1/61*(R*20+G*40+B) or some other methods
	getLuminance(radMap, lum);	

	//Pseudo Code : log(base)=Bilateral(log(input intensity))
	logImage( lum, logLum );
	bilateralFilter( logLum, logBase );

	//Pseudo Code : log(detail)=log(input intensity)-log(base)
	getDetail( logLum, logBase, logDetail );

	printf("press\n");
	printf("[q] : satisfied\n");
	printf("[w] : increase contrast\n");
	printf("[s] : decrease contrast\n");
	printf("[a] : decrease amount of change per press\n");
	printf("[d] : increase amount of change per press\n");
	int key = -1;
	float changeAmount = 0.3;
	while(key!=113)
	{
	//Pseudo Code : output intensity=exp( log(base)*compressionfactor+log(detail) - log_absolute_scale )
	getOutputLuminance( logBase, logDetail, outLum, contrast );

	//Pseudo Code : R output = r*output intensity) 
	backToRGB( radMap, lum, outLum, floatTone );
	floatToChar( floatTone, toneMap );


		cvNamedWindow( "bilateral" );
		cvShowImage( "bilateral", toneMap );
		cvSaveImage( "bilateral.bmp", toneMap );	

		key = cvWaitKey(0);
		switch(key)
		{
		case 119:
			contrast += changeAmount;
			break;
		case 115:
			contrast = max( 0.0001, contrast - changeAmount );
			break;
		case 97:
			changeAmount = max(0.01, changeAmount-0.02);
			break;
		case 100:
			changeAmount = changeAmount+0.02;
			break;
		}
		printf("\rchange amount = %.3f, constrat = %.3f", changeAmount, contrast);
	}

	printf("\n");

	cvReleaseImage( &lum );
	cvReleaseImage( &logLum );
	cvReleaseImage( &logBase );
	cvReleaseImage( &logDetail );
	cvReleaseImage( &outLum );
	cvReleaseImage( &floatTone );
}