#include <cstdio>

#include "cv.h"
#include "cxcore.h"
#include "highgui.h"

//this function would do alignment by translate img to the same position of refImg
//the translated image would be saved in img if aliImg==NULL, 
//or the function would assume aliImg is already initialized, and save the translated image in aliImg
void alignment(IplImage* refImg,
				   IplImage* img,
				   IplImage* alignedImg = NULL,
				   float noiseRange = 3);

//align multiple image at once
void alignment(IplImage* refImg,
				   IplImage** imgs,
				   int N,
				   float noiseRange = 3);

//rebuild response curve
//P is the number of picture, channel is 0~2 (BGR)
void responseCurve(float rc[256],
				    float* exposure_time,
					IplImage** imgs,					
					int P,
					int channel);

//reconstruct radiance map from response curve
//P is the number of picture
void reconstructRadianceMap(IplImage* radMap, 
								IplImage** imgs, 
								float* shutter_speed,
								int P,
								float rRC[256], 
								float gRC[256], 
								float bRC[256] );