Purpose: Recover the radience maps from multiple pictures with different exposure, and then do tone mapping do get a better picture.



Command: HDR [description file] 
         or 
	 HDR [description file] [path]

	 Example:
		HDR ..\ckliang\lib02 lib02.txt

	 Note: Both the description file and the image file will be loaded from the path


	 
Description File (Text) Format:

         [Number of Pictures]
	 image 1     exposure_time
         image 2     exposure_time
             .             .
             .             .
             .             .

	Example:
		3
		01.bmp 1          
		02.bmp 0.5        
		03.bmp 0.25


Input  : Description file and pictures with different exposures.




Output : Three images in BMP format and one image in HDR format.
	 1. noToneMapping.bmp : 
		Image scaled from HDR to 0~255 directly.

	 2. dodging.bmp :
		Tone mapping using "dodging and burning" in "Photographics Tone Reproduction for Digital Images." Erik Reinhard, Michael Stark, Peter Shirley, Jim Ferwerda, SIGGRAPH 2002

	 3. bilateral.bmp :
		Tone mapping using "bilateral filtering" in "Fast Bilateral Filtering for the Display of High Dynamic Range Images." Fredo Durand, Julie Dorsey, SIGGRAPH 2002.

	 4. HDR.hdr :
		Stored Radience Map
	 
	Response function
	g.txt : 
		g(Z) for each channel (R, G, B).
		g(Z) = ln(E)+ln(dt), where Z is the pixel value, E the irradiance, and dt the exposure time.


Others : The HDR radience maps is recovered using the algorithm in "Recovering High Dynamic Range Radiance Maps from Photographs." Paul E. Debevec, Jitendra Malik, SIGGRAPH 1997.
