#include "HDR.h"
#include "cvImage.h"

//can do inplace operation
void translate(IplImage *src, IplImage *dst, int x, int y)
{
	IplImage* img = cvCreateImage( cvSize(src->width, src->height), 8, 1 );
	cvCopyImage( src, img );
	BwImage Img( img ), Dst(dst);
	cvZero( dst );
	int height = dst->height, width = dst->width;
	for(int i=0;i<height;++i)
		for(int j=0;j<width;++j)
			Dst[i][j] = Img[min(max(0,i-y),height-1)][min(max(0,j-x),width-1)];
	cvReleaseImage( &img );
}

//can do inplace operation
void translateRgbImage(IplImage *src, IplImage *dst, int x, int y)
{
	IplImage* img = cvCreateImage( cvSize(src->width, src->height), 8, 3 );
	cvCopyImage( src, img );
	RgbImage Img( img ), Dst(dst);
	cvZero( dst );
	int height = dst->height, width = dst->width;
	for(int i=0;i<height;++i)
		for(int j=0;j<width;++j)
		{
			Dst[i][j].r = Img[min(max(0,i-y),height-1)][min(max(0,j-x),width-1)].r;
			Dst[i][j].g = Img[min(max(0,i-y),height-1)][min(max(0,j-x),width-1)].g;
			Dst[i][j].b = Img[min(max(0,i-y),height-1)][min(max(0,j-x),width-1)].b;
		}
	cvReleaseImage( &img );
}


void downSampleAlignment(IplImage* binary1,
							IplImage* binary2,
							IplImage* mask1,
							IplImage* mask2,
							int &rep_x,
							int &rep_y,
							int level)
{
	int width = binary1->width;
	int height = binary2->height;

	if(level!=0)
	{
		IplImage *qBinary1 = cvCreateImage( cvSize(width/2, height/2), 8, 1 );
		IplImage *qBinary2 = cvCreateImage( cvSize(width/2, height/2), 8, 1 );
		IplImage *qMask1 = cvCreateImage( cvSize(width/2, height/2), 8, 1 );
		IplImage *qMask2 = cvCreateImage( cvSize(width/2, height/2), 8, 1 );

		cvResize( binary1, qBinary1, CV_INTER_NN );
		cvResize( binary2, qBinary2, CV_INTER_NN );
		cvResize( mask1, qMask1, CV_INTER_NN );
		cvResize( mask2, qMask2, CV_INTER_NN );
	
		downSampleAlignment(qBinary1, qBinary2, qMask1,	qMask2,	rep_x, rep_y, level-1);
		rep_x *= 2;
		rep_y *= 2;

		cvReleaseImage( &qBinary1 );
		cvReleaseImage( &qBinary2 );
		cvReleaseImage( &qMask1 );
		cvReleaseImage( &qMask2 );

		////////
		IplImage *translatedBinary = cvCreateImage( cvSize(width, height), 8, 1 );
		IplImage *translatedMask = cvCreateImage( cvSize(width, height), 8, 1 );
		IplImage *xor =  cvCreateImage( cvSize(width, height), 8, 1 );
		
		int min = height * width;
		int min_x = rep_x, min_y = rep_y;
		for(int y=rep_y-1;y<=rep_y+1;++y)
			for(int x=rep_x-1;x<=rep_x+1;++x)
			{
				translate( binary2, translatedBinary, x, y );
				translate( mask2, translatedMask, x, y );
				cvXor( binary1, translatedBinary, translatedBinary );
				cvAnd( translatedBinary, mask1, translatedBinary );
				cvAnd( translatedBinary, translatedMask, translatedBinary );

				int cost = cvCountNonZero( translatedBinary );
				if(cost<min)
				{
					min = cost;
					min_x = x;
					min_y = y;
				}
			}

		rep_x = min_x;
		rep_y = min_y;
		cvReleaseImage( &translatedBinary );
		cvReleaseImage( &translatedMask );
		cvReleaseImage( &xor );
	}
	else
	{
		////////
		IplImage *translatedBinary = cvCreateImage( cvSize(width, height), 8, 1 );
		IplImage *translatedMask = cvCreateImage( cvSize(width, height), 8, 1 );
		IplImage *xor =  cvCreateImage( cvSize(width, height), 8, 1 );
		
		int min = height * width;
		int min_x = 0, min_y = 0;
		for(int y=-1;y<=1;++y)
			for(int x=-1;x<=1;++x)
			{
				translate( binary2, translatedBinary, x, y );
				translate( mask2, translatedMask, x, y );
				cvXor( binary1, translatedBinary, translatedBinary );
				cvAnd( translatedBinary, mask1, translatedBinary );
				cvAnd( translatedBinary, translatedMask, translatedBinary );

				int cost = cvCountNonZero( translatedBinary );
				if(cost<min)
				{
					min = cost;
					min_x = x;
					min_y = y;
				}
			}

		rep_x = min_x;
		rep_y = min_y;

		cvReleaseImage( &translatedBinary );
		cvReleaseImage( &translatedMask );
		cvReleaseImage( &xor );		
	}
}

void alignment(IplImage* refImg,
				   IplImage* img,
				   IplImage* aliImg,
				   float noiseRange)
{
	if(refImg->width!=img->width || refImg->height!=img->height)
		fprintf(stderr, "the size of the two input images do not match");
	int width = img->width, height = img->height;

	IplImage *grayImg1 = cvCreateImage( cvSize(width, height), 8, 1 );
	IplImage *grayImg2 = cvCreateImage( cvSize(width, height), 8, 1 );
	IplImage *binary1 = cvCreateImage( cvSize(width, height), 8, 1 );
	IplImage *binary2 = cvCreateImage( cvSize(width, height), 8, 1 );
	IplImage *mask1 = cvCreateImage( cvSize(width, height), 8, 1 );
	IplImage *mask2 = cvCreateImage( cvSize(width, height), 8, 1 );
	cvCvtColor( refImg, grayImg1, CV_BGR2GRAY );
	cvCvtColor( img   , grayImg2, CV_BGR2GRAY );

	//calculate the histogram
	int hist1[256], hist2[256];
	for(int i=0;i<256;++i)
		hist1[i] = hist2[i] = 0;
	BwImage GrayImg1( grayImg1 ), GrayImg2( grayImg2 );
	for(int i=0;i<height;++i)
		for(int j=0;j<width;++j)
		{
			hist1[GrayImg1[i][j]]++;
			hist2[GrayImg2[i][j]]++;
		}

	//find the median
	int threshold1 = 0, threshold2 = 0;
	int medianNum = (int)(0.5 * width * height);
	for(int i=0;i<256;++i)
	{
		threshold1 += hist1[i];
		if(threshold1>=medianNum)
		{
			threshold1 = i;
			break;
		}
	}
	for(int i=0;i<256;++i)
	{
		threshold2 += hist2[i];
		if(threshold2>=medianNum)
		{
			threshold2 = i;
			break;
		}
	}

	//get the binary map and the mask
	BwImage Binary1(binary1), Binary2(binary2), Mask1(mask1), Mask2(mask2);
	cvZero( binary1 );
	cvZero( binary2 );
	cvZero( mask1 );
	cvZero( mask2 );
	for(int i=0;i<height;++i)
		for(int j=0;j<width;++j)
		{
			if(GrayImg1[i][j]>=threshold1)
				Binary1[i][j] = 1;
			if(GrayImg1[i][j]<threshold1-noiseRange || GrayImg1[i][j]>threshold1+noiseRange)
				Mask1[i][j] = 1;
			if(GrayImg2[i][j]>=threshold2)
				Binary2[i][j] = 1;
			if(GrayImg2[i][j]<threshold2-noiseRange || GrayImg2[i][j]>threshold2+noiseRange)
				Mask2[i][j] = 1;
		}

#define MAX_OFFSET 5
	int rep_x, rep_y;
	downSampleAlignment(binary1, binary2, mask1, mask2, rep_x, rep_y, 3);
	
	if(aliImg==NULL)
		translateRgbImage( img, img, rep_x, rep_y );
	else
		translateRgbImage( img, aliImg, rep_x, rep_y );
}

void alignment(IplImage* refImg,
				   IplImage** imgs,
				   int N,
				   float noiseRange)
{
	for(int i = 0;i<N; ++i)
		alignment( refImg, imgs[i] );
}